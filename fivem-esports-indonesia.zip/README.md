# FiveM E-Sports Indonesia — Website

Website statis premium untuk FiveM E-Sports Indonesia. Dibuat dengan HTML, CSS, dan JavaScript murni; tidak memerlukan build step atau framework.

## Jalankan lokal
Buka `index.html` di browser, atau jalankan server lokal seperti Live Server di VS Code.

## Deploy ke GitHub Pages
1. Buat repository GitHub baru.
2. Upload semua file dan folder dari project ini.
3. Buka **Settings → Pages**.
4. Pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu Save.

## Deploy ke Vercel
1. Push folder ini ke repository GitHub.
2. Di Vercel, pilih **Add New → Project** dan import repository tersebut.
3. Framework preset: **Other**. Build command dan output directory bisa dikosongkan; root project berisi `index.html`.
4. Klik **Deploy**.

## Kustomisasi
- Logo: ganti `assets/logo-fivem-esports.jpg` dengan file logo terbaru (nama file tetap sama).
- Tautan sosial: edit URL di `index.html`.
- Berita: bagian `#berita` berisi kartu editorial contoh. Ganti dengan berita yang sudah terverifikasi sebelum dipublikasikan sebagai berita aktual.
- Warna dan layout: edit variabel CSS di bagian `:root` pada `styles.css`.

## Catatan
Website ini merupakan landing page statis. Tidak ada CMS atau dashboard admin untuk mengelola berita; konten berita perlu diedit di `index.html`. Font menggunakan Google Fonts, dengan fallback sistem jika tidak tersedia.
